#ifndef NODE_H
#define NODE_H

#include <QObject>
#include <QString>

class Node : public QObject
{
    Q_OBJECT
public:
    explicit Node(QObject *parent = 0);
    
signals:
    
public slots:

private:
    int mac;
    QString ip;

public:
    int status;
    int getMac();
    QString getIp();
    void setMac(int);
    void setIp(QString);
    
};

#endif // NODE_H
