#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QThread>
#include "worker.h"
#include <QString>

namespace Ui {
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT
    
public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();

private slots:
    void onShowData(QString);
    void onShowNode(int);
    void onImageReceived(QString);
    void on_btnExit_clicked();

    void on_btnConnect_clicked();

    void on_btnView_clicked();

    void on_btnSend_clicked();

    void on_btnExit_2_clicked();
    
    void on_boxSensor1_currentIndexChanged(const QString &arg1);

    void on_boxSensor2_currentIndexChanged(const QString &arg1);

    void on_boxSensor3_currentIndexChanged(const QString &arg1);

    void on_boxSensor4_currentIndexChanged(const QString &arg1);

    void on_boxSensor5_currentIndexChanged(const QString &arg1);

    void on_boxSensor6_currentIndexChanged(const QString &arg1);

    void on_boxSensor7_currentIndexChanged(const QString &arg1);

    void on_boxSensor8_currentIndexChanged(const QString &arg1);

private:
    Ui::MainWindow *ui;
    QThread *thread;
    Worker *worker;

};

#endif // MAINWINDOW_H
