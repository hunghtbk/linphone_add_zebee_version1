#ifndef CHECK_CBX_MAP_H
#define CHECK_CBX_MAP_H
#include <QString>
int Check(QString);
#endif // CHECK_CBX_MAP_H
