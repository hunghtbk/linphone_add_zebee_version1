#ifndef WORKER_H
#define WORKER_H

#include <QObject>
#include "node.h"

#define NUMBEROFNODES 10

class Worker : public QObject
{
    Q_OBJECT
public:
    explicit Worker(QObject *parent = 0);
    void requestWork();
    void setNameDevice(QString);
    void WriteByte(char*, int);
    void WriteHex(QString);
    
signals:
    void workRequested();
    void receiveData(QString);
    void nodeJoin(int);
    void debug(QString);
    void ImageReceived(QString);
    
public slots:
    void doWork();

private:
    int fd; //File Description
    QString name_dv;

public:
    Node node[NUMBEROFNODES];

private:
    void WriteAppend(QString, QString);
    
};

#endif // WORKER_H
