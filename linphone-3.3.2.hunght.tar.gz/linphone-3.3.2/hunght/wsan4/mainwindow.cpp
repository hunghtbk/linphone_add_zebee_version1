#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QFileDialog>
#include "Check_cbx_map.h"
#include <QDebug>

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    //QString name_device=ui->comboBox_device->currentText();
    ui->setupUi(this);
    thread = new QThread();
    worker = new Worker();
    worker->moveToThread(thread);

    connect(worker, SIGNAL(workRequested()), thread, SLOT(start()));
    connect(thread, SIGNAL(started()), worker, SLOT(doWork()));
    connect(worker, SIGNAL(receiveData(QString)), SLOT(onShowData(QString)));
    connect(worker, SIGNAL(nodeJoin(int)), SLOT(onShowNode(int)));
    connect(worker, SIGNAL(ImageReceived(QString)), SLOT(onImageReceived(QString)));

    ui->boxSensor1->setDisabled(true); ui->led1->turnOff(true);
    ui->boxSensor2->setDisabled(true); ui->led2->turnOff(true);
    ui->boxSensor3->setDisabled(true); ui->led3->turnOff(true);
    ui->boxSensor4->setDisabled(true); ui->led4->turnOff(true);
    ui->boxSensor5->setDisabled(true); ui->led5->turnOff(true);
    ui->boxSensor6->setDisabled(true); ui->led6->turnOff(true);
    ui->boxSensor7->setDisabled(true); ui->led7->turnOff(true);
    ui->boxSensor8->setDisabled(true); ui->led8->turnOff(true);
    //qDebug()<<name_device;
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::onShowData(QString s)
{
    ui->txtReceive->insertPlainText(s);
    ui->txtReceive->insertPlainText("\n");
    ui->txtReceive->moveCursor(QTextCursor::End);
}

void MainWindow::onShowNode(int mac)
{
    QString tmp;
    tmp = "Node " + QString::number(mac) + " gia nhap voi dia chi mang " + worker->node[mac].getIp();
    ui->txtReceive->insertPlainText(tmp);
    ui->txtReceive->insertPlainText("\n");
    if(worker->node[mac].status > 1)
    {
        worker->node[mac].status = 1;
    } else {
        tmp = "Sensor " + QString::number(mac);
        ui->boxSensor->addItem(tmp, mac);
        switch(mac)
        {
            case 1:
                ui->led1->turnOn(true);
                ui->boxSensor1->setDisabled(false);
                break;
            case 2:
                ui->led2->turnOn(true);
                ui->boxSensor2->setDisabled(false);
                break;
            case 3:
                ui->led3->turnOn(true);
                ui->boxSensor3->setDisabled(false);
                break;
            case 4:
                ui->led4->turnOn(true);
                ui->boxSensor4->setDisabled(false);
                break;
            case 5:
                ui->led5->turnOn(true);
                ui->boxSensor5->setDisabled(false);
                break;
            case 6:
                ui->led6->turnOn(true);
                ui->boxSensor6->setDisabled(false);
                break;
            case 7:
                ui->led7->turnOn(true);
                ui->boxSensor7->setDisabled(false);
                break;
            case 8:
                ui->led8->turnOn(true);
                ui->boxSensor8->setDisabled(false);
                break;
            default: break;
        }
    }
}

void MainWindow::onImageReceived(QString FileName)
{
    QImage image(FileName);
    ui->lblImage->setPixmap (QPixmap::fromImage (image));
}

void MainWindow::on_btnExit_clicked()
{
    this->close();
}

void MainWindow::on_btnConnect_clicked()
{
    QString name_device=ui->comboBox_device->currentText();
    qDebug()<<name_device;
    worker->setNameDevice(name_device);
    worker->requestWork();
    ui->txtReceive->insertPlainText("------------- Da mo cong du lieu -----------\n");
}

void MainWindow::on_btnView_clicked()
{
    QFileDialog dialog(this);
    dialog.setNameFilter (tr("Image (*.png *.xpm *.jpg *jpeg)"));
    dialog.setViewMode (QFileDialog::Detail);
    QString fileName= QFileDialog::getOpenFileName (this,tr("Open Image"),"/home/hunght/Images/"
                                                        ,tr("Image File (*.png *.jpg *.bmp *jpeg)"));
    if(!fileName.isEmpty ()){
        QImage image(fileName);
        ui->lblImage->setPixmap (QPixmap::fromImage (image));
    }
}

void MainWindow::on_btnSend_clicked()
{
    int mac;
    mac = ui->boxSensor->itemData(ui->boxSensor->currentIndex()).toInt();
    QString cmd = worker->node[mac].getIp();
    if((mac != 0) && (cmd.compare("")))
    {
        switch(ui->boxCommand->currentIndex())
        {
            case 1: cmd += "000$"; break;
            case 2: cmd += "400$"; break;
            default: break;
        }
        QString tmp = "Gui ma lenh " + cmd;
        ui->txtReceive->insertPlainText(tmp);
        ui->txtReceive->insertPlainText("\n");
        worker->WriteHex(cmd);
    }
}

void MainWindow::on_btnExit_2_clicked()
{
    this->close();
}


void MainWindow::on_boxSensor1_currentIndexChanged(const QString &arg1)
{
    int mac,_cmd;
    QString LENH;
    mac = ui->boxSensor->itemData(ui->boxSensor->currentIndex()).toInt();
    QString cmd = worker->node[mac].getIp();
    if((mac != 0) && (cmd.compare("")))
    {
        _cmd=Check(ui->boxSensor1->currentText());
        switch(_cmd){
             case 1: LENH="Warning Level 1";break;
             case 2: LENH="Warning Level 2";break;
             case 3: LENH="Warning Level 3";break;
             case 4: LENH="Warning Level 4";break;
             case 5: LENH="Warning Level 4";break;
             case 6: LENH="Take Photo";cmd += "400$";break;
             case 7: LENH="Take Temperature and Humidy";cmd += "000$";break;
        }

    }
    qDebug()<<LENH<<cmd;
    worker->WriteHex(cmd);
    QString tmp = "Gui ma lenh " + cmd;
    ui->txtReceive->insertPlainText(tmp);
    ui->txtReceive->insertPlainText("\n");

}

void MainWindow::on_boxSensor2_currentIndexChanged(const QString &arg1)
{
    int mac,_cmd;
    QString LENH;
    mac = ui->boxSensor->itemData(ui->boxSensor->currentIndex()).toInt();
    QString cmd = worker->node[mac].getIp();
    if((mac != 0) && (cmd.compare("")))
    {
        _cmd=Check(ui->boxSensor2->currentText());
        switch(_cmd){
             case 1: LENH="Warning Level 1";break;
             case 2: LENH="Warning Level 2";break;
             case 3: LENH="Warning Level 3";break;
             case 4: LENH="Warning Level 4";break;
             case 5: LENH="Warning Level 4";break;
             case 6: LENH="Take Photo";cmd += "400$";break;
             case 7: LENH="Take Temperature and Humidy";cmd += "000$";break;

        }
        worker->WriteHex(cmd);
        QString tmp = "Gui ma lenh " + cmd;
        ui->txtReceive->insertPlainText(tmp);
        ui->txtReceive->insertPlainText("\n");
    }

    qDebug()<<LENH<<cmd;
}

void MainWindow::on_boxSensor3_currentIndexChanged(const QString &arg1)
{
    int mac,_cmd;
    QString LENH;
    mac = ui->boxSensor->itemData(ui->boxSensor->currentIndex()).toInt();
    QString cmd = worker->node[mac].getIp();
    if((mac != 0) && (cmd.compare("")))
    {
        _cmd=Check(ui->boxSensor3->currentText());
        switch(_cmd){
             case 1: LENH="Warning Level 1";break;
             case 2: LENH="Warning Level 2";break;
             case 3: LENH="Warning Level 3";break;
             case 4: LENH="Warning Level 4";break;
             case 5: LENH="Warning Level 4";break;
             case 6: LENH="Take Photo";cmd += "400$";break;
             case 7: LENH="Take Temperature and Humidy";cmd += "000$";break;

        }
        worker->WriteHex(cmd);
        QString tmp = "Gui ma lenh " + cmd;
        ui->txtReceive->insertPlainText(tmp);
        ui->txtReceive->insertPlainText("\n");
    }

    qDebug()<<LENH<<cmd;
}

void MainWindow::on_boxSensor4_currentIndexChanged(const QString &arg1)
{
    int mac,_cmd;
    QString LENH;
    mac = ui->boxSensor->itemData(ui->boxSensor->currentIndex()).toInt();
    QString cmd = worker->node[mac].getIp();
    if((mac != 0) && (cmd.compare("")))
    {
        _cmd=Check(ui->boxSensor4->currentText());
        switch(_cmd){
             case 1: LENH="Warning Level 1";break;
             case 2: LENH="Warning Level 2";break;
             case 3: LENH="Warning Level 3";break;
             case 4: LENH="Warning Level 4";break;
             case 5: LENH="Warning Level 4";break;
             case 6: LENH="Take Photo";cmd += "400$";break;
             case 7: LENH="Take Temperature and Humidy";cmd += "000$";break;

        }
        worker->WriteHex(cmd);
        QString tmp = "Gui ma lenh " + cmd;
        ui->txtReceive->insertPlainText(tmp);
        ui->txtReceive->insertPlainText("\n");
    }

    qDebug()<<LENH<<cmd;
}

void MainWindow::on_boxSensor5_currentIndexChanged(const QString &arg1)
{
    int mac,_cmd;
    QString LENH;
    mac = ui->boxSensor->itemData(ui->boxSensor->currentIndex()).toInt();
    QString cmd = worker->node[mac].getIp();
    if((mac != 0) && (cmd.compare("")))
    {
        _cmd=Check(ui->boxSensor5->currentText());
        switch(_cmd){
             case 1: LENH="Warning Level 1";break;
             case 2: LENH="Warning Level 2";break;
             case 3: LENH="Warning Level 3";break;
             case 4: LENH="Warning Level 4";break;
             case 5: LENH="Warning Level 4";break;
             case 6: LENH="Take Photo";cmd += "400$";break;
             case 7: LENH="Take Temperature and Humidy";cmd += "000$";break;

        }
        worker->WriteHex(cmd);
        QString tmp = "Gui ma lenh " + cmd;
        ui->txtReceive->insertPlainText(tmp);
        ui->txtReceive->insertPlainText("\n");
    }

    qDebug()<<LENH<<cmd;
}

void MainWindow::on_boxSensor6_currentIndexChanged(const QString &arg1)
{
    int mac,_cmd;
    QString LENH;
    mac = ui->boxSensor->itemData(ui->boxSensor->currentIndex()).toInt();
    QString cmd = worker->node[mac].getIp();
    if((mac != 0) && (cmd.compare("")))
    {
        _cmd=Check(ui->boxSensor6->currentText());
        switch(_cmd){
             case 1: LENH="Warning Level 1";break;
             case 2: LENH="Warning Level 2";break;
             case 3: LENH="Warning Level 3";break;
             case 4: LENH="Warning Level 4";break;
             case 5: LENH="Warning Level 4";break;
             case 6: LENH="Take Photo";cmd += "400$";break;
             case 7: LENH="Take Temperature and Humidy";cmd += "000$";break;

        }
        worker->WriteHex(cmd);
        QString tmp = "Gui ma lenh " + cmd;
        ui->txtReceive->insertPlainText(tmp);
        ui->txtReceive->insertPlainText("\n");
    }

    qDebug()<<LENH<<cmd;
}

void MainWindow::on_boxSensor7_currentIndexChanged(const QString &arg1)
{
    int mac,_cmd;
    QString LENH;
    mac = ui->boxSensor->itemData(ui->boxSensor->currentIndex()).toInt();
    QString cmd = worker->node[mac].getIp();
    if((mac != 0) && (cmd.compare("")))
    {
        _cmd=Check(ui->boxSensor7->currentText());
        switch(_cmd){
             case 1: LENH="Warning Level 1";break;
             case 2: LENH="Warning Level 2";break;
             case 3: LENH="Warning Level 3";break;
             case 4: LENH="Warning Level 4";break;
             case 5: LENH="Warning Level 4";break;
             case 6: LENH="Take Photo";cmd += "400$";break;
             case 7: LENH="Take Temperature and Humidy";cmd += "000$";break;

        }
        worker->WriteHex(cmd);
        QString tmp = "Gui ma lenh " + cmd;
        ui->txtReceive->insertPlainText(tmp);
        ui->txtReceive->insertPlainText("\n");
    }

    qDebug()<<LENH<<cmd;
}

void MainWindow::on_boxSensor8_currentIndexChanged(const QString &arg1)
{
    int mac,_cmd;
    QString LENH;
    mac = ui->boxSensor->itemData(ui->boxSensor->currentIndex()).toInt();
    QString cmd = worker->node[mac].getIp();
    if((mac != 0) && (cmd.compare("")))
    {
        _cmd=Check(ui->boxSensor8->currentText());
        switch(_cmd){
             case 1: LENH="Warning Level 1";break;
             case 2: LENH="Warning Level 2";break;
             case 3: LENH="Warning Level 3";break;
             case 4: LENH="Warning Level 4";break;
             case 5: LENH="Warning Level 4";break;
             case 6: LENH="Take Photo";cmd += "400$";break;
             case 7: LENH="Take Temperature and Humidy";cmd += "000$";break;

        }
        worker->WriteHex(cmd);
        QString tmp = "Gui ma lenh " + cmd;
        ui->txtReceive->insertPlainText(tmp);
        ui->txtReceive->insertPlainText("\n");
    }

    qDebug()<<LENH<<cmd;
}
