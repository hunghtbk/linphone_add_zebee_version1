#include "node.h"

Node::Node(QObject *parent) :
    QObject(parent)
{
    status = 0;
    ip = "";
}

int Node::getMac()
{
    return mac;
}

QString Node::getIp()
{
    return ip;
}

void Node::setMac(int value)
{
    mac = value;
}

void Node::setIp(QString value)
{
    ip = value;
}
