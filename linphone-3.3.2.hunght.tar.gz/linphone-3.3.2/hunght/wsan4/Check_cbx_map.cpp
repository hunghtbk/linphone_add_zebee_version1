#include "Check_cbx_map.h"

int Check(QString _cmd)
{
    if(!_cmd.compare("Take Temperature and Humidy"))return 7;
    if(!_cmd.compare("Take Photo"))return 6;
    if(!_cmd.compare("Warning Level 1"))return 1;
    if(!_cmd.compare("Warning Level 2"))return 2;
    if(!_cmd.compare("Warning Level 3"))return 3;
    if(!_cmd.compare("Warning Level 4"))return 4;
    if(!_cmd.compare("Warning Level 5"))return 5;
}
