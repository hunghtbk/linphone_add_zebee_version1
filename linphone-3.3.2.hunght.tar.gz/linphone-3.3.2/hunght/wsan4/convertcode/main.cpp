// convert_native_string_to_Byte_array.cpp
// compile with: /clr
#include <string.h>
#include <iostream>
#include <QString>
#include <QDebug>
using namespace std;

void WriteHex(QString str)
{
    int hex_val;
    int hex_len = str.length()/2;
    char hex[hex_len];
    int i;
    QString tmp;
    for(i = 0; i < hex_len; i++){
        tmp = str.mid(i*2, 2);
        bool ok;
        hex_val = tmp.toInt(&ok, 16);
        hex[i] = (char)hex_val;
    }
    QString string = hex;

    //Convert QString to Byte Array Here
    QByteArray array (string.toStdString().c_str());

    //Let's Print ByteArray Data
    qDebug()<<array.data();
}
int main() {
    QString str="123";
    int hex_val;
    int hex_len = str.length()/2;
    char hex[hex_len];
    int i;
    QString tmp;
    for(i = 0; i < hex_len; i++){
        tmp = str.mid(i*2, 2);
        bool ok;
        hex_val = tmp.toInt(&ok, 16);
        hex[i] = (char)hex_val;
    }
    qDebug()<<hex;
}
